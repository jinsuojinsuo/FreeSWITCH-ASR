Linux:

1. 解压SDK压缩包
2. cd build
3. cmake ../
4. make clean
5. make
6. cd ../demo
7. ./asrDemo test.wav config-asr.txt 1 1  your-id your-key 1
